package com.github.kr328.clash.common.constants

import com.github.kr328.clash.common.util.packageName

object Permissions {
    val RECEIVE_SELF_BROADCASTS = "$packageName.permission.RECEIVE_BROADCASTS"
}