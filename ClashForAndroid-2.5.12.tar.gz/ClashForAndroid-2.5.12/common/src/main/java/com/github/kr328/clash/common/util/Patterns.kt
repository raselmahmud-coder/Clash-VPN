package com.github.kr328.clash.common.util

val PatternFileName = Regex("[^*&%\\n\\r/]+")